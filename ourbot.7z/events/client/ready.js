module.exports=bot=>{
    console.log(`Hi, ${bot.user.username} is now online!`)
}