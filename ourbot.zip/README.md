# ourbot
Discord bot using discord.js for our Destiny 2 Clan
